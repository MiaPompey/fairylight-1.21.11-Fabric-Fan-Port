package de.lucalabs.fairylights.main.items.crafting.ingredient;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntComparators;
import it.unimi.dsi.fastutil.ints.IntList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.player.StackedContents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;

public class LazyTagIngredient extends Ingredient {
    private final TagKey<Item> tag;

    private LazyTagIngredient(final TagKey<Item> tag) {
        super(Stream.empty());
        this.tag = tag;
    }

    @Override
    public ItemStack @NotNull [] getItems() {
        return StreamSupport.stream(BuiltInRegistries.ITEM.getTagOrEmpty(this.tag).spliterator(), false).map(ItemStack::new).toArray(ItemStack[]::new);
    }

    @Override
    public boolean test(@Nullable final ItemStack stack) {
        return stack != null && stack.is(this.tag);
    }

    @Override
    public @NotNull IntList getStackingIds() {
        final ItemStack[] stacks = this.getItems();
        final IntList list = new IntArrayList(stacks.length);
        for (final ItemStack stack : stacks) {
            list.add(StackedContents.getStackingIndex(stack));
        }
        list.sort(IntComparators.NATURAL_COMPARATOR);
        return list;
    }

    @Override
    public boolean isEmpty() {
        return !BuiltInRegistries.ITEM.getTagOrEmpty(this.tag).iterator().hasNext();
    }

    public static @NotNull LazyTagIngredient of(final @NotNull TagKey<Item> tag) {
        return new LazyTagIngredient(tag);
    }
}
